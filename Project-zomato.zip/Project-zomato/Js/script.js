// Function to fade in elements on load
document.addEventListener("DOMContentLoaded", function () {
    const mainContent = document.querySelector("main");
    mainContent.style.opacity = 0;
    mainContent.style.transition = "opacity 2s ease-in-out";

    // Trigger the fade-in effect after a slight delay
    setTimeout(() => {
        mainContent.style.opacity = 1;
    }, 200);
});

// Adding interactivity to the search input
document.querySelector("main input").addEventListener("focus", function () {
    this.style.borderColor = "#b71c1c"; // Darker shade of red on focus
});

document.querySelector("main input").addEventListener("blur", function () {
    this.style.borderColor = "#d32f2f"; // Original red border on blur
});
