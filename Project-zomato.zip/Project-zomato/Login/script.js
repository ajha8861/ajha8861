// Get elements
const otpBtn = document.querySelector(".otp-btn");
const emailLoginBtn = document.querySelector(".email-login");
const googleLoginBtn = document.querySelector(".google-login");

// Button click animation function
function animateButtonClick(button) {
    button.style.animation = "buttonClick 0.3s ease";
    button.addEventListener("animationend", () => {
        button.style.animation = ""; // Remove animation class after it completes
    });
}

// Apply click animations to buttons
otpBtn.addEventListener("click", () => animateButtonClick(otpBtn));
emailLoginBtn.addEventListener("click", () => animateButtonClick(emailLoginBtn));
googleLoginBtn.addEventListener("click", () => animateButtonClick(googleLoginBtn));

// Add fade-in effect when the page loads
window.addEventListener("load", () => {
    document.querySelector(".login-content").classList.add("fadeIn");
});
